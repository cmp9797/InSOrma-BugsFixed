package com.example.quiz1.adapter;

public class UserAdapter {
}
