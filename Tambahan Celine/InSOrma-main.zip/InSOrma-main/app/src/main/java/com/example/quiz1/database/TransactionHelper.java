package com.example.quiz1.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.quiz1.models.Transaction;

import java.util.ArrayList;

public class TransactionHelper {
    private static String TABLE_NAME = "msTransactions";
    private static String FIELD_ID = "id";
    private static String FIELD_USERID = "userId";
    private static String FIELD_PROCUCTID = "productId";
    private static String FIELD_DATE = "transactionDate";
    private static String FIELD_QTY = "quantity";


    private SqlHelper sqlHelper;
    private SQLiteDatabase db;
    private Context context;
    private ContentValues cv;

    public void open() throws SQLException{
        sqlHelper = new SqlHelper(context);
        db = sqlHelper.getWritableDatabase();
    }

    public void close() throws SQLException{
        sqlHelper.close();
    }

//    //view transactions
//    public ArrayList<Transaction> viewTransactions{
//        ArrayList<Transaction> transList = new ArrayList<Transaction>();
//        String query = "SELECT * FROM " + TABLE_MS_TR;
//
//        Cursor cursor = db.rawQuery(query, null);
//        cursor.moveToFirst();
//
//        return transList;
//
//    }






    public void createTableSong(SQLiteDatabase db){
        String query = "CREATE TABLE IF NOT EXISTS '"+ TABLE_NAME + "'(\n" +
                "'" + FIELD_ID + "' TEXT,\n"+
                "'" + FIELD_USERID + "' TEXT,\n"+
                "'" + FIELD_PROCUCTID + "' TEXT,\n"+
                "'" + FIELD_DATE + "' TEXT,\n"+
                "'" + FIELD_QTY + "' INTEGER);";

        //EXCECUTE QUERI -> jalanin kuerinya
        db.execSQL(query);
    }

//    public void insertTransaction(Context context, Transaction transaction){
//        SqlHelper helper = new SqlHelper(context);
//        SQLiteDatabase db = helper.getWritableDatabase();
//        ContentValues cv = new ContentValues();
//
//        cv.put(FIELD_MS_TR_ID, transaction.getId());
//        cv.put(FIELD_MS_TR_USERID, transaction.getUserId());
//        cv.put(FIELD_MS_TR_PROCUCTID, transaction.getProductId());
//        cv.put(FIELD_MS_TR_DATE, transaction.getTransactionDate());
//        cv.put(FIELD_MS_TR_QTY, transaction.getQuantity());
//
//        db.insertWithOnConflict(
//                TABLE_MS_TR,
//                null,
//                cv,
//                SQLiteDatabase.CONFLICT_IGNORE //ga ngefek -> masih ga bisa unik
//        );
//        db.close();
//    }

    public void insertTransaction(Context context, Transaction transaction){
        SqlHelper helper = new SqlHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();

//        String query = "CREATE TABLE IF NOT EXISTS '"+ TABLE_MS_TR + "'(\n" +
//                "'" + FIELD_MS_TR_ID + "' TEXT,\n"+
//                "'" + FIELD_MS_TR_USERID + "' TEXT,\n"+
//                "'" + FIELD_MS_TR_PROCUCTID+ "' TEXT,\n"+
//                "'" + FIELD_MS_TR_DATE + "' TEXT,\n"+
//                "'" + FIELD_MS_TR_QTY + "' INTEGER);"

        String query = "SELECT * \n" +
                "FROM '" + TABLE_NAME +"'\n" +
                "ORDER BY '" + FIELD_ID +"' DESC LIMIT 1";

        Cursor cursor = db.rawQuery(query,null);

        int id;
//        if(cursor.moveToNext()){
//            id = ((int) cursor.getString(0).substring(2)) + 1;
//            int n
//        }

        cv.put(TABLE_NAME, transaction.getId());
        cv.put(FIELD_ID, transaction.getUserId());
        cv.put(FIELD_PROCUCTID, transaction.getProductId());
        cv.put(FIELD_DATE, transaction.getTransactionDate());
        cv.put(FIELD_QTY, transaction.getQuantity());

        db.insertWithOnConflict(
                TABLE_NAME,
                null,
                cv,
                SQLiteDatabase.CONFLICT_IGNORE //ga ngefek -> masih ga bisa unik
        );
        db.close();
    }}
