package com.example.quiz1.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.quiz1.data.UserData;
import com.example.quiz1.fragment.RegisterFragment;
import com.example.quiz1.models.Transaction;
import com.example.quiz1.models.User;

import java.util.ArrayList;
import java.util.Vector;

public class UserHelper {
        private static String TABLE_NAME = "MsUsers";
        private static String FIELD_ID = "Id";
        private static String FIELD_EMAIL= "Email";
        private static String FIELD_NAME= "Name";
        private static String FIELD_PHONE = "Phone";
        private static String FIELD_PASS = "Password";

        UserData userData;

        //view data
//        public Vector<User> getAllUsers(Context context) {
//            SqlHelper sqlHelper = new SqlHelper(context);
//            SQLiteDatabase db = sqlHelper.getWritableDatabase();
//            Vector<User> usersData = new Vector<User>();
//            String query = "SELECT * FROM " + TABLE_NAME;
//
//            Cursor cursor = db.rawQuery(query, null);
//
//            int id;
//            String email, name, phone, pass;
//
//            while(cursor.moveToNext()){
//                id = cursor.getInt(0);
//                email = cursor.getString(1);
//                name = cursor.getString(2);
//                phone = cursor.getString(3);
//                pass = cursor.getString(4);
//                usersData.add(new User(id,email,name,phone,pass));
//            }
//            cursor.close();
//            return usersData;
//        }

    public void getAllUsers(Context context) {
        SqlHelper sqlHelper = new SqlHelper(context);
        SQLiteDatabase db = sqlHelper.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;

        Cursor cursor = db.rawQuery(query, null);

        int id;
        String email, name, phone, pass;

        while(cursor.moveToNext()){
            id = cursor.getInt(0);
            email = cursor.getString(1);
            name = cursor.getString(2);
            phone = cursor.getString(3);
            pass = cursor.getString(4);
            User userAdded = new User(id,email,name,phone,pass);
            userData.getVectUser().add(userAdded);
        }
        cursor.close();
    }

        //create table
        public void createTableUser(SQLiteDatabase db){

            String qCreate = "CREATE TABLE IF NOT EXISTS '"+ TABLE_NAME + "'(\n" +
                    "'" + FIELD_ID + "' INTEGER,\n"+
                    "'" + FIELD_EMAIL + "' TEXT, \n"+
                    "'" + FIELD_NAME + "' TEXT,\n"+
                    "'" + FIELD_PHONE + "' TEXT,\n"+
                    "'" + FIELD_PASS + "' TEXT\n)";

            //excecute query -> jalanin kuerinya
            db.execSQL(qCreate);
            db.close();
        }

        //insert to database
        public void insertUser(Context context, User user){
            SqlHelper sqlHelper = new SqlHelper(context);
            SQLiteDatabase db = sqlHelper.getWritableDatabase();

//            ContentValues cv = new ContentValues();
//            cv.put(FIELD_ID, user.getId());
//            cv.put(FIELD_EMAIL, user.getEmailAddress());
//            cv.put(FIELD_NAME, user.getUsername());
//            cv.put(FIELD_PHONE, user.getPhoneNum());
//            cv.put(FIELD_PASS, user.getPassword());
//
//            db.insertWithOnConflict(
//                    TABLE_NAME,
//                    null,
//                    cv,
//                    SQLiteDatabase.CONFLICT_NONE //ga ngefek -> masih ga bisa unik
//            );

            String query = "SELECT * FROM " + TABLE_NAME;
            Cursor cursor = db.rawQuery(query, null);

            int duplicateFlag = 0;
            String email, pass;

            while(cursor.moveToNext()){
                email = cursor.getString(1);
                pass = cursor.getString(4);
                if(email.equals(user.getEmailAddress()) || pass.equals(user.getPassword())){
                    duplicateFlag = 1;
                    break;
                }
            }
            cursor.close();

            if(duplicateFlag == 0){
                query =
                        "INSERT INTO "+ TABLE_NAME +" ("+
                                FIELD_ID + ", "+ FIELD_EMAIL+ ", "+ FIELD_NAME + ", "+
                                FIELD_PHONE+ ", "+ FIELD_PASS+")\n" +
                                "VALUES ( " + user.getId() +", " +
                                "'" + user.getEmailAddress() +"', " +
                                "'" + user.getUsername() +"', " +
                                "'" + user.getPhoneNum() +"', " +
                                "'" + user.getPassword() +"')\n";

                db.execSQL(query);
                db.close();
                userData.getVectUser().add(user);
            }
        }

        public void updateUsername(Context context, User user){
            SqlHelper sqlHelper = new SqlHelper(context);
            SQLiteDatabase db = sqlHelper.getWritableDatabase();

            String query =
                    "UPDATE " + TABLE_NAME +" SET \n" +
                            FIELD_NAME +" = "+ user.getUsername()+"\n" +
                    "WHERE " + FIELD_ID + " =" + user.getId();

            db.execSQL(query);
            db.close();
        }

        public void deleteData(Context context, User user){
            SqlHelper sqlHelper = new SqlHelper(context);
            SQLiteDatabase db = sqlHelper.getWritableDatabase();

            String query =
                    "DELETE FROM "+ TABLE_NAME +"\n"+
                    "WHERE " + FIELD_ID + " =" + user.getId();

            db.execSQL(query);
            db.close();
        }

        public void deleteAllData(Context context){
            SqlHelper sqlHelper = new SqlHelper(context);
            SQLiteDatabase db = sqlHelper.getWritableDatabase();

            String query =
                    "DELETE FROM "+ TABLE_NAME ;

            db.execSQL(query);
            db.close();

//            userData.getVectUser().removeAllElements();
        }
}
