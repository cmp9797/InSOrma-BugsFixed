package com.example.quiz1.data;

import java.util.Vector;

public class ConnectorData {

}
