package com.example.quiz1.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.quiz1.data.FurnitureData;
import com.example.quiz1.models.Furniture;

import java.util.ArrayList;
import java.util.Vector;

public class FurnitureHelper {
    private static String TABLE_NAME = "MsFurnitures";
    private static String FIELD_ID = "Id";
    private static String FIELD_NAME= "Name";
    private static String FIELD_RATING= "Rating";
    private static String FIELD_PRC= "Price";
    private static String FIELD_IMG_SRC = "ImageSource";
    private static String FIELD_DESC = "Description";

    FurnitureData furnitureData;

    //view data
    public ArrayList<Furniture> viewFurniture (Context context) {
        SqlHelper sqlHelper = new SqlHelper(context);
        SQLiteDatabase db = sqlHelper.getWritableDatabase();
        ArrayList<Furniture> furnitureList = new ArrayList<Furniture>();
        String query = "SELECT * FROM " + TABLE_NAME;

        Cursor cursor = db.rawQuery(query, null);

        int id, price;
        double rating;
        String name, image, desc;

        while(cursor.moveToNext()){
            id = cursor.getInt(0);
            name = cursor.getString(1);
            rating = cursor.getDouble(2);
            price = cursor.getInt(3);
            image = cursor.getString(4);
            desc = cursor.getString(5);
            furnitureList.add(new Furniture(id, name, rating, price, image, desc));
        }
        cursor.close();
        return furnitureList;
    }

    //create table
    public void createTableFurniture(SQLiteDatabase db){

        String qCreate = "CREATE TABLE IF NOT EXISTS '"+ TABLE_NAME + "'(\n" +
                "'" + FIELD_ID + "' INTEGER,\n"+
                "'" + FIELD_NAME + "' TEXT, \n"+
                "'" + FIELD_RATING + "' REAL,\n"+
                "'" + FIELD_PRC + "' INTEGER,\n"+
                "'" + FIELD_IMG_SRC + "' TEXT,\n"+
                "'" + FIELD_DESC + "' TEXT\n)";

        //excecute query -> jalanin kuerinya
        db.execSQL(qCreate);
        db.close();
    }

    //insert to database
    public void insertFurniture(Context context, Furniture furniture){
        SqlHelper sqlHelper = new SqlHelper(context);
        SQLiteDatabase db = sqlHelper.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);

        int duplicateFlag = 0;
        String name;

        while(cursor.moveToNext()){
            name = cursor.getString(1);
            if(name.equals(furniture.getName()) ){
                duplicateFlag = 1;
                break;
            }
        }
        cursor.close();

        if(duplicateFlag == 0){
            query =
                    "INSERT INTO "+ TABLE_NAME +" ("+
                            FIELD_ID + ", "+ FIELD_NAME+ ", "+ FIELD_RATING + ", "+
                            FIELD_PRC + ", "+ FIELD_IMG_SRC+ ", "+ FIELD_DESC +")\n" +
                            "VALUES ( " + furniture.getId() +", " +
                            "'" + furniture.getName() +"', " +
                            "'" + furniture.getRating() +"', " +
                            "'" + furniture.getPrice() +"', " +
                            "'" + furniture.getImage() +"', " +
                            "'" + furniture.getDescription() +"')\n";

            db.execSQL(query);
            db.close();
        }
    }

    public void insertFurnitures(Context context, Vector<Furniture> furnitures){
        SqlHelper sqlHelper = new SqlHelper(context);
        SQLiteDatabase db = sqlHelper.getWritableDatabase();


        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToNext()){
            deleteAllData(context);
        }
        cursor.close();

        for (Furniture furniture:furnitures) {
            query =
                    "INSERT INTO "+ TABLE_NAME +" ("+
                            FIELD_ID + ", "+ FIELD_NAME+ ", "+ FIELD_RATING + ", "+
                            FIELD_PRC + ", "+ FIELD_IMG_SRC+ ", "+ FIELD_DESC +")\n" +
                            "VALUES ( " + furniture.getId() +", " +
                            "'" + furniture.getName() +"', " +
                            "'" + furniture.getRating() +"', " +
                            "'" + furniture.getPrice() +"', " +
                            "'" + furniture.getImage() +"', " +
                            "'" + furniture.getDescription() +"')\n";
            db.execSQL(query);
        }
        db.close();

    }

    public void deleteData(Context context, Furniture furniture){
        SqlHelper sqlHelper = new SqlHelper(context);
        SQLiteDatabase db = sqlHelper.getWritableDatabase();

        String query =
                "DELETE FROM "+ TABLE_NAME +"\n"+
                        "WHERE " + FIELD_ID + " =" + furniture.getId();

        db.execSQL(query);
        db.close();
    }

    public void deleteAllData(Context context){
        SqlHelper sqlHelper = new SqlHelper(context);
        SQLiteDatabase db = sqlHelper.getWritableDatabase();

        String query =
                "DELETE FROM "+ TABLE_NAME ;

        db.execSQL(query);
        db.close();
    }
}
